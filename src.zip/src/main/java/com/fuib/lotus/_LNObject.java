/**
 * This interface must be implements by all 'fuib' classes uses inside itself a 
 * any classes from notes.jar  
**/
package com.fuib.lotus;

/**
 * @author gorobets
 *
 */
public interface _LNObject extends lotus.domino.Base {
//	void recycle();			// pseudo-destructor. Must be called from 'finally' block
//	String toString();							// 'string' presentation of object	
}

